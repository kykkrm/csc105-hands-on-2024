import React from 'react'

const SignUpPage = () => {
  return (
    <div>
        <h1 className='pl-4 font-sans pt-2 text-2xl'>SignUpPage</h1>
      </div>
  )
}

export default SignUpPage